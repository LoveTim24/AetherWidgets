/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Smartphone, 
  Layout, 
  Database, 
  Code2, 
  Github, 
  Download, 
  Sparkles, 
  Flame, 
  Moon, 
  Sword, 
  Star, 
  Heart,
  ChevronRight,
  ExternalLink,
  Terminal
} from 'lucide-react';

// Theme Categories
const THEMES = [
  { id: 'gothic', name: 'Gothic', icon: <Moon className="w-5 h-5" />, color: '#8B0000', description: 'Dark, mysterious, and elegant.' },
  { id: 'crusader', name: 'Crusader', icon: <Sword className="w-5 h-5" />, color: '#C0C0C0', description: 'Medieval era steel and valor.' },
  { id: 'dragon', name: 'Dragon Legend', icon: <Flame className="w-5 h-5" />, color: '#FF4500', description: 'Mythical beasts in 3D pixel art.' },
  { id: 'cosmos', name: 'Star/Cosmos', icon: <Star className="w-5 h-5" />, color: '#483D8B', description: 'Infinite space and celestial bodies.' },
  { id: 'cute', name: 'Cute Core', icon: <Heart className="w-5 h-5" />, color: '#FF69B4', description: 'Soft, pastel, and adorable.' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'preview' | 'code' | 'docs'>('preview');
  const [selectedTheme, setSelectedTheme] = useState(THEMES[0]);

  return (
    <div className="min-h-screen bg-[#1A110B] text-[#E4E3E0] font-sans selection:bg-red-900/30">
      {/* Navigation */}
      <nav className="border-b border-white/5 bg-[#2C1E16]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(220,38,38,0.5)]">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold tracking-tighter text-xl font-pixel text-xs">AETHER</span>
          </div>
          
          <div className="flex items-center gap-8 text-sm font-medium">
            <button 
              onClick={() => setActiveTab('preview')}
              className={`transition-colors ${activeTab === 'preview' ? 'text-red-500' : 'hover:text-white'}`}
            >
              Live Preview
            </button>
            <button 
              onClick={() => setActiveTab('code')}
              className={`transition-colors ${activeTab === 'code' ? 'text-red-500' : 'hover:text-white'}`}
            >
              Swift Code
            </button>
            <button 
              onClick={() => setActiveTab('docs')}
              className={`transition-colors ${activeTab === 'docs' ? 'text-red-500' : 'hover:text-white'}`}
            >
              Documentation
            </button>
          </div>

          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 bg-white/5 hover:bg-white/10 px-4 py-2 rounded-full text-sm transition-all border border-white/10">
              <Github className="w-4 h-4" />
              <span>Open Source</span>
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          {activeTab === 'preview' && (
            <motion.div 
              key="preview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid lg:grid-cols-2 gap-16 items-start"
            >
              {/* Left: Phone Preview */}
              <div className="flex justify-center">
                <div className="relative w-[320px] h-[650px] bg-black rounded-[3rem] border-[8px] border-[#333] shadow-2xl overflow-hidden">
                  {/* Notch */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-7 bg-black rounded-b-2xl z-50"></div>
                  
                  {/* Screen Content */}
                  <div className="h-full bg-[#2C1E16] overflow-y-auto scrollbar-hide">
                    {/* Banner */}
                    <div className="h-40 bg-gradient-to-b from-black/40 to-transparent relative overflow-hidden">
                      <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/gothic/400/200')] bg-cover bg-center opacity-50 grayscale contrast-125"></div>
                      <div className="absolute inset-0 bg-gradient-to-t from-[#2C1E16] to-transparent"></div>
                    </div>

                    {/* Profile Header */}
                    <div className="px-6 -mt-12 relative z-10">
                      <div className="relative inline-block">
                        <div className="w-24 h-24 rounded-full bg-[#1A110B] border-4 border-[#2C1E16] overflow-hidden relative group">
                          <img 
                            src="https://picsum.photos/seed/avatar/100/100" 
                            alt="Avatar" 
                            className="w-full h-full object-cover grayscale"
                            referrerPolicy="no-referrer"
                          />
                          {/* Red Halo Effect */}
                          <div className="absolute inset-0 rounded-full shadow-[inset_0_0_20px_rgba(255,0,0,0.8)] animate-pulse"></div>
                        </div>
                        {/* Status Indicator */}
                        <div className="absolute bottom-1 right-1 w-6 h-6 bg-green-500 border-4 border-[#2C1E16] rounded-full"></div>
                      </div>

                      <div className="mt-4">
                        <h2 className="text-xl font-pixel tracking-tighter">Aether User</h2>
                        <p className="text-white/40 text-sm font-mono">@pixel_gothic</p>
                      </div>

                      {/* Decorative Branch (Simulated) */}
                      <div className="mt-6 p-4 bg-black/20 rounded-xl border border-white/5 relative overflow-hidden">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-green-900/30 rounded-lg flex items-center justify-center">
                            <Flame className="w-6 h-6 text-red-500" />
                          </div>
                          <div>
                            <p className="text-[8px] font-pixel text-red-400 uppercase tracking-widest">Active Theme</p>
                            <p className="text-sm font-medium">{selectedTheme.name}</p>
                          </div>
                        </div>
                        {/* Pixel Flowers Decor */}
                        <div className="absolute top-2 right-2 flex gap-1">
                          <div className="w-2 h-2 bg-red-600"></div>
                          <div className="w-2 h-2 bg-orange-600"></div>
                        </div>
                      </div>

                      {/* Theme Gallery */}
                      <div className="mt-8">
                        <p className="text-[8px] font-pixel text-white/30 uppercase tracking-[0.2em] mb-4">Gallery</p>
                        <div className="grid grid-cols-2 gap-3">
                          {THEMES.map((theme) => (
                            <button
                              key={theme.id}
                              onClick={() => setSelectedTheme(theme)}
                              className={`p-3 rounded-xl border transition-all text-left group ${
                                selectedTheme.id === theme.id 
                                ? 'bg-white/10 border-white/20' 
                                : 'bg-white/5 border-transparent hover:border-white/10'
                              }`}
                            >
                              <div className="mb-2 opacity-50 group-hover:opacity-100 transition-opacity">
                                {theme.icon}
                              </div>
                              <p className="text-xs font-bold">{theme.name}</p>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Widget Preview */}
                      <div className="mt-8 pb-12">
                        <p className="text-[8px] font-pixel text-white/30 uppercase tracking-[0.2em] mb-4">Widget Preview</p>
                        <div className="aspect-square w-full bg-[#1A110B] rounded-[2rem] border-2 border-white/5 flex flex-col items-center justify-center p-6 text-center group cursor-pointer hover:border-red-500/30 transition-all">
                          <div className="w-20 h-20 bg-red-500/10 rounded-2xl flex items-center justify-center mb-4 shadow-[0_0_30px_rgba(239,68,68,0.1)] group-hover:scale-110 transition-transform">
                            {selectedTheme.icon}
                          </div>
                          <h3 className="font-pixel text-[8px] mb-1">{selectedTheme.name} Interactive</h3>
                          <p className="text-[10px] text-white/40 leading-relaxed max-w-[150px]">
                            Tap to trigger 3D pixel animation
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Info & Features */}
              <div className="space-y-12 pt-8">
                <div>
                  <h1 className="text-5xl font-bold tracking-tighter mb-6 leading-tight font-pixel">
                    3D Pixel Art <br />
                    <span className="text-red-500 text-3xl">Interactive Widgets</span>
                  </h1>
                  <p className="text-lg text-white/60 leading-relaxed max-w-lg">
                    A unique iOS experience inspired by Gothic aesthetics and Discord profiles. 
                    Built with SwiftUI and WidgetKit for deep home screen integration.
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-8">
                  <FeatureCard 
                    icon={<Layout className="w-6 h-6" />}
                    title="WidgetKit"
                    desc="Interactive widgets for iOS 17+ with AppIntents."
                  />
                  <FeatureCard 
                    icon={<Database className="w-6 h-6" />}
                    title="Firebase Ready"
                    desc="Architected for Firestore & Storage dynamic updates."
                  />
                  <FeatureCard 
                    icon={<Smartphone className="w-6 h-6" />}
                    title="SwiftUI"
                    desc="Modern, declarative UI with custom animations."
                  />
                  <FeatureCard 
                    icon={<Code2 className="w-6 h-6" />}
                    title="Open Source"
                    desc="Clean MVVM architecture ready for GitHub."
                  />
                </div>

                <div className="p-6 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-bold mb-1">Ready to build?</p>
                    <p className="text-xs text-white/40">Download the Swift project structure below.</p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('code')}
                    className="bg-red-600 hover:bg-red-500 text-white px-6 py-2 rounded-full text-sm font-bold transition-all shadow-lg shadow-red-600/20"
                  >
                    View Source
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'code' && (
            <motion.div 
              key="code"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold tracking-tight">Project Structure</h2>
                  <p className="text-white/40 text-sm mt-1">Explore the Swift files generated for this project.</p>
                </div>
                <div className="flex gap-3">
                  <button className="flex items-center gap-2 bg-white/5 hover:bg-white/10 px-4 py-2 rounded-lg text-sm transition-all border border-white/10">
                    <Download className="w-4 h-4" />
                    <span>Download ZIP</span>
                  </button>
                </div>
              </div>

              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 space-y-2">
                  <FileItem name="AetherApp.swift" type="app" active />
                  <FileItem name="Models/Theme.swift" type="model" />
                  <FileItem name="ViewModels/ThemeViewModel.swift" type="vm" />
                  <FileItem name="Services/FirebaseService.swift" type="service" />
                  <FileItem name="Views/MainView.swift" type="view" />
                  <FileItem name="WidgetExtension/AetherWidget.swift" type="widget" />
                  <FileItem name="WidgetExtension/AppIntent.swift" type="intent" />
                </div>
                <div className="lg:col-span-2 bg-black/40 rounded-2xl border border-white/10 p-6 font-mono text-sm overflow-x-auto">
                  <div className="flex items-center gap-2 mb-4 text-white/30 border-b border-white/5 pb-4">
                    <Terminal className="w-4 h-4" />
                    <span>AetherApp.swift</span>
                  </div>
                  <pre className="text-red-400/90">
{`import SwiftUI

@main
struct AetherApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
                .preferredColorScheme(.dark)
        }
    }
}`}
                  </pre>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'docs' && (
            <motion.div 
              key="docs"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="max-w-3xl mx-auto space-y-12"
            >
              <section>
                <h2 className="text-3xl font-bold mb-6">Building Locally</h2>
                <div className="space-y-6 text-white/70 leading-relaxed">
                  <p>To build this project on your local machine, follow these steps:</p>
                  <ol className="list-decimal list-inside space-y-4 ml-4">
                    <li>Install <span className="text-white font-bold">Xcode 15+</span> from the Mac App Store.</li>
                    <li>Create a new SwiftUI project named <span className="text-red-400">"AetherWidgets"</span>.</li>
                    <li>Add a <span className="text-white font-bold">Widget Extension</span> target to your project.</li>
                    <li>Copy the provided Swift files into their respective directories.</li>
                    <li>Add the <span className="text-white font-bold">Firebase iOS SDK</span> via Swift Package Manager.</li>
                    <li>Configure your <span className="text-red-400">GoogleService-Info.plist</span> from the Firebase Console.</li>
                  </ol>
                </div>
              </section>

              <section className="p-8 bg-red-900/10 rounded-3xl border border-red-500/20">
                <h3 className="text-xl font-bold text-red-400 mb-4 flex items-center gap-2">
                  <Flame className="w-5 h-5" />
                  Interactive Widgets (iOS 17)
                </h3>
                <p className="text-sm text-white/60 mb-6">
                  The interactivity is handled by <code className="bg-black/40 px-2 py-1 rounded text-red-300">AppIntents</code>. 
                  When the user taps the widget, the <code className="bg-black/40 px-2 py-1 rounded text-red-300">ToggleAnimationIntent</code> 
                  is triggered, allowing you to update local state or fetch new data from Firebase without opening the main app.
                </p>
                <div className="flex gap-4">
                  <a href="#" className="text-xs font-bold flex items-center gap-1 hover:text-white transition-colors">
                    Apple Documentation <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-12 mt-24">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3 opacity-50">
            <Sparkles className="w-5 h-5" />
            <span className="font-bold tracking-tighter">AETHER</span>
          </div>
          <p className="text-xs text-white/20 font-mono">
            &copy; 2026 Aether Interactive. Open Source under Apache-2.0.
          </p>
          <div className="flex gap-6 text-white/40">
            <Github className="w-5 h-5 hover:text-white cursor-pointer transition-colors" />
            <Smartphone className="w-5 h-5 hover:text-white cursor-pointer transition-colors" />
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="p-6 bg-white/5 rounded-2xl border border-white/10 hover:border-white/20 transition-all group">
      <div className="w-12 h-12 bg-red-500/10 rounded-xl flex items-center justify-center mb-4 text-red-500 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="font-bold mb-2">{title}</h3>
      <p className="text-sm text-white/40 leading-relaxed">{desc}</p>
    </div>
  );
}

function FileItem({ name, type, active = false }: { name: string, type: string, active?: boolean }) {
  return (
    <div className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${active ? 'bg-red-500/10 border border-red-500/20 text-red-400' : 'hover:bg-white/5 text-white/40'}`}>
      <div className="flex items-center gap-3">
        <Code2 className="w-4 h-4" />
        <span className="text-sm font-medium">{name}</span>
      </div>
      <span className="text-[10px] font-bold uppercase tracking-widest opacity-40">{type}</span>
    </div>
  );
}
